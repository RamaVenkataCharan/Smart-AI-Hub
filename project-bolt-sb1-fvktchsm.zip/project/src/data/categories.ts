import { Category } from '../types';

export const categories: Category[] = [
  {
    id: 'writing',
    name: 'Writing',
    slug: 'writing',
    description: 'AI tools for content creation, copywriting, and text generation',
    icon: 'PenTool',
    color: '#3B82F6',
    toolCount: 45
  },
  {
    id: 'coding',
    name: 'Coding',
    slug: 'coding',
    description: 'Development tools, code generation, and programming assistants',
    icon: 'Code',
    color: '#10B981',
    toolCount: 38
  },
  {
    id: 'design',
    name: 'Design',
    slug: 'design',
    description: 'Creative tools for graphic design, UI/UX, and visual content',
    icon: 'Palette',
    color: '#F59E0B',
    toolCount: 32
  },
  {
    id: 'marketing',
    name: 'Marketing',
    slug: 'marketing',
    description: 'Marketing automation, SEO, social media, and advertising tools',
    icon: 'TrendingUp',
    color: '#EF4444',
    toolCount: 42
  },
  {
    id: 'productivity',
    name: 'Productivity',
    slug: 'productivity',
    description: 'Task management, automation, and workflow optimization tools',
    icon: 'Zap',
    color: '#8B5CF6',
    toolCount: 28
  },
  {
    id: 'education',
    name: 'Education',
    slug: 'education',
    description: 'Learning platforms, tutoring, and educational content creation',
    icon: 'BookOpen',
    color: '#06B6D4',
    toolCount: 25
  },
  {
    id: 'business',
    name: 'Business',
    slug: 'business',
    description: 'Business intelligence, analytics, and enterprise solutions',
    icon: 'Building',
    color: '#84CC16',
    toolCount: 35
  },
  {
    id: 'media',
    name: 'Media',
    slug: 'media',
    description: 'Video, audio, and multimedia content creation tools',
    icon: 'Video',
    color: '#F97316',
    toolCount: 22
  }
];