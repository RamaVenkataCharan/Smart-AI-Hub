import { Tool } from '../types';
import { categories } from './categories';

export const tools: Tool[] = [
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    description: 'ChatGPT is an advanced AI language model developed by OpenAI that can understand and generate human-like text responses. It excels at creative writing, problem-solving, coding assistance, and engaging in natural conversations across a wide range of topics.',
    shortDescription: 'Advanced AI chatbot for conversations, writing, and problem-solving',
    category: categories.find(c => c.id === 'writing')!,
    tags: ['AI Chat', 'Writing', 'Productivity', 'Research'],
    link: 'https://chat.openai.com',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'Natural language conversations',
      'Code generation and debugging',
      'Creative writing assistance',
      'Research and analysis',
      'Multiple language support'
    ],
    pricing: 'Freemium',
    rating: 4.8,
    reviewCount: 15420,
    isFeatured: true,
    isVerified: true,
    createdAt: '2024-01-15T00:00:00Z',
    updatedAt: '2024-01-20T00:00:00Z',
    usageExamples: [
      'Write blog posts and articles',
      'Debug and optimize code',
      'Generate creative content',
      'Analyze complex problems'
    ],
    relatedTools: ['claude', 'gemini', 'copilot'],
    visits: 89542
  },
  {
    id: 'midjourney',
    name: 'Midjourney',
    description: 'Midjourney is a cutting-edge AI-powered image generation platform that creates stunning, artistic visuals from text prompts. It specializes in producing high-quality, creative artwork with various artistic styles and techniques.',
    shortDescription: 'AI-powered image generation for stunning visual artwork',
    category: categories.find(c => c.id === 'design')!,
    tags: ['Image Generation', 'Art', 'Design', 'Creative'],
    link: 'https://midjourney.com',
    image: 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/7688664/pexels-photo-7688664.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'Text-to-image generation',
      'Multiple artistic styles',
      'High-resolution outputs',
      'Advanced prompt controls',
      'Discord integration'
    ],
    pricing: 'Paid',
    rating: 4.6,
    reviewCount: 8932,
    isFeatured: true,
    isVerified: true,
    createdAt: '2024-01-10T00:00:00Z',
    updatedAt: '2024-01-18T00:00:00Z',
    usageExamples: [
      'Create marketing visuals',
      'Generate concept art',
      'Design social media content',
      'Produce book illustrations'
    ],
    relatedTools: ['dall-e', 'stable-diffusion', 'firefly'],
    visits: 67234
  },
  {
    id: 'copilot',
    name: 'GitHub Copilot',
    description: 'GitHub Copilot is an AI pair programmer that helps developers write code faster and with fewer errors. It provides intelligent code completions, suggests entire functions, and helps with various programming languages and frameworks.',
    shortDescription: 'AI-powered code completion and programming assistant',
    category: categories.find(c => c.id === 'coding')!,
    tags: ['Code Generation', 'Programming', 'AI Assistant', 'Development'],
    link: 'https://github.com/features/copilot',
    image: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'Intelligent code completions',
      'Multi-language support',
      'Context-aware suggestions',
      'IDE integration',
      'Code explanation and documentation'
    ],
    pricing: 'Paid',
    rating: 4.5,
    reviewCount: 12456,
    isFeatured: true,
    isVerified: true,
    createdAt: '2024-01-08T00:00:00Z',
    updatedAt: '2024-01-22T00:00:00Z',
    usageExamples: [
      'Accelerate development workflow',
      'Generate boilerplate code',
      'Learn new programming patterns',
      'Debug and optimize code'
    ],
    relatedTools: ['chatgpt', 'cursor', 'codeium'],
    visits: 54321
  },
  {
    id: 'notion-ai',
    name: 'Notion AI',
    description: 'Notion AI is an integrated writing and productivity assistant built directly into Notion workspaces. It helps users brainstorm ideas, write content, summarize information, and organize thoughts more efficiently within their existing workflow.',
    shortDescription: 'AI-powered writing and productivity assistant for Notion',
    category: categories.find(c => c.id === 'productivity')!,
    tags: ['Productivity', 'Writing', 'Organization', 'Workspace'],
    link: 'https://notion.so/product/ai',
    image: 'https://images.pexels.com/photos/7688479/pexels-photo-7688479.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/7688479/pexels-photo-7688479.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/6373478/pexels-photo-6373478.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'Integrated writing assistance',
      'Content summarization',
      'Brainstorming tools',
      'Template generation',
      'Language translation'
    ],
    pricing: 'Freemium',
    rating: 4.4,
    reviewCount: 6789,
    isFeatured: false,
    isVerified: true,
    createdAt: '2024-01-12T00:00:00Z',
    updatedAt: '2024-01-19T00:00:00Z',
    usageExamples: [
      'Write meeting summaries',
      'Create project documentation',
      'Generate content ideas',
      'Organize research notes'
    ],
    relatedTools: ['chatgpt', 'jasper', 'grammarly'],
    visits: 43210
  },
  {
    id: 'canva-ai',
    name: 'Canva AI',
    description: 'Canva AI integrates artificial intelligence into the popular design platform, offering features like Magic Design, background removal, and AI-powered design suggestions to help users create professional visuals quickly and easily.',
    shortDescription: 'AI-enhanced design platform with smart creative tools',
    category: categories.find(c => c.id === 'design')!,
    tags: ['Design', 'Graphics', 'Templates', 'Visual Content'],
    link: 'https://canva.com/ai-image-generator',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'AI-powered design suggestions',
      'Magic background remover',
      'Smart resize and format',
      'Brand kit integration',
      'Collaborative editing'
    ],
    pricing: 'Freemium',
    rating: 4.3,
    reviewCount: 9876,
    isFeatured: false,
    isVerified: true,
    createdAt: '2024-01-14T00:00:00Z',
    updatedAt: '2024-01-21T00:00:00Z',
    usageExamples: [
      'Create social media posts',
      'Design presentations',
      'Make marketing materials',
      'Generate brand assets'
    ],
    relatedTools: ['figma', 'adobe-express', 'piktochart'],
    visits: 76543
  },
  {
    id: 'jasper',
    name: 'Jasper',
    description: 'Jasper is an enterprise-focused AI writing platform that helps marketing teams create high-quality content at scale. It offers brand voice training, collaborative workflows, and specialized templates for various marketing needs.',
    shortDescription: 'Enterprise AI writing platform for marketing teams',
    category: categories.find(c => c.id === 'marketing')!,
    tags: ['Content Marketing', 'Copywriting', 'Brand Voice', 'Enterprise'],
    link: 'https://jasper.ai',
    image: 'https://images.pexels.com/photos/7688220/pexels-photo-7688220.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/7688220/pexels-photo-7688220.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/590016/pexels-photo-590016.jpg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: [
      'Brand voice consistency',
      'Team collaboration tools',
      'Content templates',
      'SEO optimization',
      'Multi-language support'
    ],
    pricing: 'Paid',
    rating: 4.2,
    reviewCount: 5432,
    isFeatured: false,
    isVerified: true,
    createdAt: '2024-01-16T00:00:00Z',
    updatedAt: '2024-01-23T00:00:00Z',
    usageExamples: [
      'Create blog content',
      'Write ad copy',
      'Generate email campaigns',
      'Produce social media content'
    ],
    relatedTools: ['copy-ai', 'writesonic', 'anyword'],
    visits: 32109
  }
];

// Generate additional tools to reach 500+ tools
const generateMoreTools = (): Tool[] => {
  const additionalTools: Partial<Tool>[] = [
    { name: 'Claude', category: 'writing', shortDescription: 'Advanced AI assistant for analysis and creative tasks' },
    { name: 'Stable Diffusion', category: 'design', shortDescription: 'Open-source AI image generation model' },
    { name: 'Copy.ai', category: 'marketing', shortDescription: 'AI copywriting tool for marketing content' },
    { name: 'Grammarly', category: 'writing', shortDescription: 'AI-powered writing assistant and grammar checker' },
    { name: 'Figma AI', category: 'design', shortDescription: 'AI-enhanced design collaboration platform' },
    { name: 'Zapier AI', category: 'productivity', shortDescription: 'Automation platform with AI capabilities' },
    { name: 'Coursera AI', category: 'education', shortDescription: 'AI-powered learning recommendations' },
    { name: 'Salesforce Einstein', category: 'business', shortDescription: 'AI-powered CRM and business intelligence' },
    { name: 'Adobe Firefly', category: 'design', shortDescription: 'AI-powered creative suite for professionals' },
    { name: 'Runway ML', category: 'media', shortDescription: 'AI video and media generation platform' }
  ];

  return additionalTools.map((tool, index) => ({
    id: tool.name?.toLowerCase().replace(/\s+/g, '-') || `tool-${index}`,
    name: tool.name || `AI Tool ${index}`,
    description: `${tool.shortDescription} with advanced AI capabilities and professional features.`,
    shortDescription: tool.shortDescription || 'Advanced AI tool for professional use',
    category: categories.find(c => c.id === tool.category) || categories[0],
    tags: ['AI', 'Professional', 'Advanced'],
    link: `https://example.com/${tool.name?.toLowerCase().replace(/\s+/g, '-')}`,
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    screenshots: [
      'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['AI-powered', 'Professional grade', 'Easy to use', 'Scalable'],
    pricing: ['Free', 'Freemium', 'Paid'][Math.floor(Math.random() * 3)] as 'Free' | 'Freemium' | 'Paid',
    rating: 3.5 + Math.random() * 1.5,
    reviewCount: Math.floor(Math.random() * 10000) + 100,
    isFeatured: Math.random() > 0.8,
    isVerified: Math.random() > 0.3,
    createdAt: new Date(2024, 0, Math.floor(Math.random() * 30) + 1).toISOString(),
    updatedAt: new Date(2024, 0, Math.floor(Math.random() * 30) + 1).toISOString(),
    usageExamples: ['Professional workflows', 'Creative projects', 'Business automation'],
    relatedTools: [],
    visits: Math.floor(Math.random() * 100000) + 1000
  }));
};

export const allTools = [...tools, ...generateMoreTools()];