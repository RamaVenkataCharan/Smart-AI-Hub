import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { categories } from '../data/categories';
import { allTools } from '../data/tools';

const CategoriesPage: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  // Get popular tools for each category
  const getCategoryTools = (categoryId: string) => {
    return allTools
      .filter(tool => tool.category.id === categoryId)
      .sort((a, b) => b.visits - a.visits)
      .slice(0, 3);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <section className="bg-white dark:bg-gray-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-gray-900 dark:text-white mb-4"
            >
              AI Tool Categories
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
            >
              Explore our comprehensive collection of AI tools organized by categories. 
              Find the perfect tools for your specific needs and use cases.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {categories.map((category, index) => {
              const categoryTools = getCategoryTools(category.id);
              
              return (
                <motion.div
                  key={category.id}
                  variants={itemVariants}
                  className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-lg transition-all duration-300"
                >
                  <div className="p-8">
                    <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between">
                      {/* Category Info */}
                      <div className="flex items-start space-x-6 mb-6 lg:mb-0">
                        <div
                          className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: `${category.color}15` }}
                        >
                          <div
                            className="w-8 h-8 rounded-lg"
                            style={{ backgroundColor: category.color }}
                          />
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                            {category.name}
                          </h2>
                          <p className="text-gray-600 dark:text-gray-400 mb-4 max-w-2xl">
                            {category.description}
                          </p>
                          <div className="flex items-center space-x-4">
                            <span
                              className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
                              style={{
                                backgroundColor: `${category.color}15`,
                                color: category.color
                              }}
                            >
                              {category.toolCount} tools
                            </span>
                            <Link
                              to={`/tools?category=${category.id}`}
                              className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors group"
                            >
                              <span className="text-sm font-medium">View all</span>
                              <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                            </Link>
                          </div>
                        </div>
                      </div>

                      {/* Popular Tools Preview */}
                      <div className="w-full lg:w-auto">
                        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 lg:text-right">
                          Popular tools
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-3 lg:w-80">
                          {categoryTools.map((tool) => (
                            <Link
                              key={tool.id}
                              to={`/tools/${tool.id}`}
                              className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors group"
                            >
                              <img
                                src={tool.image}
                                alt={tool.name}
                                className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate">
                                  {tool.name}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                                  {tool.visits.toLocaleString()} visits
                                </p>
                              </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Can't find what you're looking for?
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
              Browse all our tools or use our advanced search to find exactly what you need.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link
                to="/tools"
                className="px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center space-x-2 group"
              >
                <span>Browse All Tools</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/tools?search="
                className="px-8 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Advanced Search
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default CategoriesPage;