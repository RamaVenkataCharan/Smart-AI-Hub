import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import ToolCard from '../components/common/ToolCard';
import SearchFilters from '../components/common/SearchFilters';
import { allTools } from '../data/tools';
import { categories } from '../data/categories';
import { SearchFilters as SearchFiltersType } from '../types';

const ToolsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [filters, setFilters] = useState<SearchFiltersType>({
    query: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    pricing: searchParams.get('pricing') || '',
    rating: Number(searchParams.get('rating')) || 0,
    sortBy: (searchParams.get('sortBy') as any) || 'popularity'
  });

  const filteredAndSortedTools = useMemo(() => {
    let filtered = allTools.filter(tool => {
      // Query filter
      if (filters.query) {
        const query = filters.query.toLowerCase();
        if (
          !tool.name.toLowerCase().includes(query) &&
          !tool.description.toLowerCase().includes(query) &&
          !tool.tags.some(tag => tag.toLowerCase().includes(query)) &&
          !tool.category.name.toLowerCase().includes(query)
        ) {
          return false;
        }
      }

      // Category filter
      if (filters.category && tool.category.id !== filters.category) {
        return false;
      }

      // Pricing filter
      if (filters.pricing && tool.pricing !== filters.pricing) {
        return false;
      }

      // Rating filter
      if (filters.rating > 0 && tool.rating < filters.rating) {
        return false;
      }

      return true;
    });

    // Sort tools
    switch (filters.sortBy) {
      case 'popularity':
        filtered.sort((a, b) => b.visits - a.visits);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    return filtered;
  }, [filters]);

  const handleFiltersChange = (newFilters: SearchFiltersType) => {
    setFilters(newFilters);
    
    // Update URL params
    const params = new URLSearchParams();
    if (newFilters.query) params.set('search', newFilters.query);
    if (newFilters.category) params.set('category', newFilters.category);
    if (newFilters.pricing) params.set('pricing', newFilters.pricing);
    if (newFilters.rating > 0) params.set('rating', newFilters.rating.toString());
    if (newFilters.sortBy !== 'popularity') params.set('sortBy', newFilters.sortBy);
    
    navigate(`/tools?${params.toString()}`, { replace: true });
  };

  const clearFilters = () => {
    const defaultFilters: SearchFiltersType = {
      query: '',
      category: '',
      pricing: '',
      rating: 0,
      sortBy: 'popularity'
    };
    setFilters(defaultFilters);
    navigate('/tools', { replace: true });
  };

  // Update filters when URL params change
  useEffect(() => {
    const newFilters: SearchFiltersType = {
      query: searchParams.get('search') || '',
      category: searchParams.get('category') || '',
      pricing: searchParams.get('pricing') || '',
      rating: Number(searchParams.get('rating')) || 0,
      sortBy: (searchParams.get('sortBy') as any) || 'popularity'
    };
    setFilters(newFilters);
  }, [searchParams]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <section className="bg-white dark:bg-gray-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              AI Tools Directory
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Discover, compare, and choose from our comprehensive collection of AI tools 
              to enhance your productivity and creativity.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <SearchFilters
        filters={filters}
        onFiltersChange={handleFiltersChange}
        onClearFilters={clearFilters}
        totalResults={filteredAndSortedTools.length}
      />

      {/* Tools Grid */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredAndSortedTools.length > 0 ? (
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {filteredAndSortedTools.map((tool) => (
                <motion.div
                  key={tool.id}
                  variants={itemVariants}
                  layout
                >
                  <ToolCard tool={tool} />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="text-center py-16">
              <div className="max-w-md mx-auto">
                <div className="w-24 h-24 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-12 h-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  No tools found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  We couldn't find any tools matching your criteria. Try adjusting your filters or search terms.
                </p>
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Categories Quick Access */}
      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Browse by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleFiltersChange({ ...filters, category: category.id })}
                className={`p-4 rounded-lg border transition-all hover:scale-105 ${
                  filters.category === category.id
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div
                  className="w-8 h-8 rounded-lg mb-2 mx-auto"
                  style={{ backgroundColor: `${category.color}15` }}
                >
                  <div
                    className="w-4 h-4 rounded mt-2 mx-auto"
                    style={{ backgroundColor: category.color }}
                  />
                </div>
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                  {category.name}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {category.toolCount} tools
                </p>
              </button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ToolsPage;