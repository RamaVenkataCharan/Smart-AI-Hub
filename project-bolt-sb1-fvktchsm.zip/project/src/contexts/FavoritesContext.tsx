import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';

interface FavoritesContextType {
  favorites: string[];
  addFavorite: (toolId: string) => void;
  removeFavorite: (toolId: string) => void;
  isFavorite: (toolId: string) => boolean;
  toggleFavorite: (toolId: string) => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

interface FavoritesProviderProps {
  children: ReactNode;
}

export const FavoritesProvider: React.FC<FavoritesProviderProps> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      setFavorites(user.favoriteTools || []);
    } else {
      // Load favorites from localStorage for non-authenticated users
      const storedFavorites = localStorage.getItem('smart-ai-hub-favorites');
      if (storedFavorites) {
        try {
          setFavorites(JSON.parse(storedFavorites));
        } catch (error) {
          console.error('Error parsing stored favorites:', error);
          setFavorites([]);
        }
      }
    }
  }, [user]);

  const addFavorite = (toolId: string): void => {
    const updatedFavorites = [...favorites, toolId];
    setFavorites(updatedFavorites);
    
    if (user) {
      // Update user's favorites in the backend (simulated)
      user.favoriteTools = updatedFavorites;
      localStorage.setItem('smart-ai-hub-user', JSON.stringify(user));
    } else {
      // Store in localStorage for non-authenticated users
      localStorage.setItem('smart-ai-hub-favorites', JSON.stringify(updatedFavorites));
    }
  };

  const removeFavorite = (toolId: string): void => {
    const updatedFavorites = favorites.filter(id => id !== toolId);
    setFavorites(updatedFavorites);
    
    if (user) {
      // Update user's favorites in the backend (simulated)
      user.favoriteTools = updatedFavorites;
      localStorage.setItem('smart-ai-hub-user', JSON.stringify(user));
    } else {
      // Store in localStorage for non-authenticated users
      localStorage.setItem('smart-ai-hub-favorites', JSON.stringify(updatedFavorites));
    }
  };

  const isFavorite = (toolId: string): boolean => {
    return favorites.includes(toolId);
  };

  const toggleFavorite = (toolId: string): void => {
    if (isFavorite(toolId)) {
      removeFavorite(toolId);
    } else {
      addFavorite(toolId);
    }
  };

  const value: FavoritesContextType = {
    favorites,
    addFavorite,
    removeFavorite,
    isFavorite,
    toggleFavorite
  };

  return (
    <FavoritesContext.Provider value={value}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = (): FavoritesContextType => {
  const context = useContext(FavoritesContext);
  if (context === undefined) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};