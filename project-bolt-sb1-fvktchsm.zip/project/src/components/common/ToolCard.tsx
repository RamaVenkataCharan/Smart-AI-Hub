import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Heart, ExternalLink, Verified, Eye } from 'lucide-react';
import { Tool } from '../../types';
import { useFavorites } from '../../contexts/FavoritesContext';
import { motion } from 'framer-motion';

interface ToolCardProps {
  tool: Tool;
  showDescription?: boolean;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool, showDescription = false }) => {
  const { isFavorite, toggleFavorite } = useFavorites();
  const isToolFavorited = isFavorite(tool.id);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const getPricingBadgeColor = (pricing: string): string => {
    switch (pricing) {
      case 'Free':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'Freemium':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'Paid':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden group hover:shadow-lg transition-all duration-300"
    >
      {/* Image */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={tool.image}
          alt={tool.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300" />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPricingBadgeColor(tool.pricing)}`}>
            {tool.pricing}
          </span>
          {tool.isVerified && (
            <div className="bg-blue-600 p-1 rounded-full">
              <Verified className="h-3 w-3 text-white" />
            </div>
          )}
        </div>

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(tool.id);
          }}
          className="absolute top-3 right-3 p-2 rounded-full bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm hover:bg-white dark:hover:bg-gray-800 transition-all duration-200 group/heart"
        >
          <Heart
            className={`h-4 w-4 transition-all duration-200 group-hover/heart:scale-110 ${
              isToolFavorited
                ? 'text-red-500 fill-red-500'
                : 'text-gray-600 dark:text-gray-400'
            }`}
          />
        </button>

        {/* External Link Button */}
        <a
          href={tool.link}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="absolute bottom-3 right-3 p-2 rounded-full bg-blue-600 text-white opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-blue-700 hover:scale-110"
        >
          <ExternalLink className="h-4 w-4" />
        </a>
      </div>

      {/* Content */}
      <Link to={`/tools/${tool.id}`} className="block p-4">
        <div className="mb-2">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-1">
            {tool.name}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mt-1">
            {showDescription ? tool.description : tool.shortDescription}
          </p>
        </div>

        {/* Category */}
        <div className="mb-3">
          <span
            className="inline-block px-2 py-1 text-xs font-medium rounded-md"
            style={{
              backgroundColor: `${tool.category.color}15`,
              color: tool.category.color
            }}
          >
            {tool.category.name}
          </span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {tool.tags.slice(0, 3).map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md"
            >
              {tag}
            </span>
          ))}
          {tool.tags.length > 3 && (
            <span className="px-2 py-1 text-xs text-gray-500 dark:text-gray-400">
              +{tool.tags.length - 3}
            </span>
          )}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm font-medium text-gray-900 dark:text-white">
                {tool.rating.toFixed(1)}
              </span>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                ({formatNumber(tool.reviewCount)})
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Eye className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {formatNumber(tool.visits)}
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default ToolCard;