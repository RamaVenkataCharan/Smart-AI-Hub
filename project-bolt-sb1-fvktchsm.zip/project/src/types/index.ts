export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'user' | 'admin';
  createdAt: string;
  favoriteTools: string[];
}

export interface Tool {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  category: Category;
  tags: string[];
  link: string;
  image: string;
  screenshots: string[];
  videoUrl?: string;
  features: string[];
  pricing: 'Free' | 'Freemium' | 'Paid';
  rating: number;
  reviewCount: number;
  isFeatured: boolean;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
  usageExamples: string[];
  relatedTools: string[];
  visits: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  toolCount: number;
}

export interface Review {
  id: string;
  userId: string;
  toolId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  isVerified: boolean;
  createdAt: string;
  helpful: number;
}

export interface SearchFilters {
  query: string;
  category: string;
  pricing: string;
  rating: number;
  sortBy: 'popularity' | 'rating' | 'newest' | 'name';
}

export interface AdminStats {
  totalTools: number;
  totalUsers: number;
  totalReviews: number;
  monthlyGrowth: number;
  popularCategories: Array<{ category: string; count: number }>;
  recentActivity: Array<{ type: string; description: string; timestamp: string }>;
}